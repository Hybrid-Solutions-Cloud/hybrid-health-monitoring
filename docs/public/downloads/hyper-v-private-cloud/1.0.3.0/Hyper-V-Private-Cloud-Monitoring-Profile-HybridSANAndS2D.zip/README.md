# Hyper-V Private Cloud Monitoring 1.0.3.0

This package contains sealed product Management Packs plus public, unsealed starter override MPs.
Import only the capability MPs selected for the deployment and import every Microsoft/vendor
prerequisite listed in elease-manifest.json first. Review and copy starter overrides into
customer-owned MPs; never use the Default Management Pack for customization.

Build mode: **Release**

Product public key token: $publicKeyToken

Test-mode packages are not public release artifacts and are not supported for production use.